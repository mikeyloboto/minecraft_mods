package jeffsmods.common.destroyerpiston;

public class CommonProxy{
	public void registerRenderers(){}

}
